const mongoose = require('mongoose');

const NoteSchema = mongoose.Schema({
    
    name:String,
    company: String,    
    phone:String,
    email:String
},{ collection: 'Note' }, {
    timestamps: true
});

const pesrsonSchema = mongoose.Schema({
    
    pname:String,
    pcompany: String,    
   pphone:String,
    pemail:String
},{ collection: 'Pesron' }, {
    timestamps: true
});

module.exports = mongoose.model('Note', NoteSchema);
//module.exports = mongoose.model('Person', pesrsonSchema);