module.exports = {
    url: 'mongodb+srv://test:test123@cluster0.x4mpz.mongodb.net/easy-notes?retryWrites=true&w=majority'
}
